<template>
    <div class="header">

    </div>
</template>
  
<script>
// @ is an alias to /src


export default {
    name: 'Header',

    props: {

    }
}
</script>


<style lang="scss">
.header {
    background-color: rgb(255, 189, 34);
    width: 100%;
    height: 50px;
}
</style>